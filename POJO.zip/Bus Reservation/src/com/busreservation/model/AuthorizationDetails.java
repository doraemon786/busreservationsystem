package com.busreservation.model;

public class AuthorizationDetails {				//POJO for storing username password
	
	private String userName;							
	private String password;							
	
	public AuthorizationDetails() {					
		super();
	}
	
	public AuthorizationDetails(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}
	
	@Override
	public String toString() {
		return "AuthorizationDetails [userName=" + userName + ", password=" + password + "]";
	}
	
	public String getUserName() {
		return userName;
	}
	
	public String getPassword() {
		return password;
	}
	
}
