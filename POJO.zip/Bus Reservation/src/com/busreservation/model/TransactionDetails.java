package com.busreservation.model;

public class TransactionDetails {
	private String source;
	private String destination;
}
