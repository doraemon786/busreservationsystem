package com.busreservation.model;

public class AuthorizedUser {											//POJO for registered/authorized users
	private int userId;															
	private String authUserName;										
	private String userEmail;												
	private int phoneNumber;											
	private String gender;													
	private float wallet;														
	
	private AuthorizationDetails authorizationDetails;			//object of authorizationdetails to include uname & pwd
	
	public AuthorizedUser() {
		super();
	}

	public AuthorizedUser(String authUserName, String userEmail, int phoneNumber, String gender, float wallet,
			AuthorizationDetails authorizationDetails) {
		super();
		this.authUserName = authUserName;
		this.userEmail = userEmail;
		this.phoneNumber = phoneNumber;
		this.gender = gender;
		this.wallet = wallet;
		this.authorizationDetails = authorizationDetails;
	}

	@Override
	public String toString() {
		return "AuthorizedUser [userId=" + userId + ", authUserName=" + authUserName + ", userEmail=" + userEmail
				+ ", phoneNumber=" + phoneNumber + ", gender=" + gender + ", wallet=" + wallet
				+ ", authorizationDetails=" + authorizationDetails + "]";
	}

	public int getUserId() {
		return userId;
	}

	public String getAuthUserName() {
		return authUserName;
	}

	public void setAuthUserName(String authUserName) {
		this.authUserName = authUserName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public int getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public float getWallet() {
		return wallet;
	}

	public void setWallet(float wallet) {
		this.wallet = wallet;
	}

	public AuthorizationDetails getAuthorizationDetails() {
		return authorizationDetails;
	}

	public void setAuthorizationDetails(AuthorizationDetails authorizationDetails) {
		this.authorizationDetails = authorizationDetails;
	}
	
}
