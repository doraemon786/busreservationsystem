package com.busreservation.model;

public class TicketDetails {
	private int ticketId;
	
	private PassengerDetails passengerDetails;
	
	private TransactionDetails transactionDetails;
}
