package com.BusReservation.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.BusReservation.model.AuthorizedUser;
import com.HibernateUtil.HibernateUtil;
@Repository
public class CustomerDaoImpl  implements ICustomerDao {
 static Transaction tcx ;
private SessionFactory sessionFactory;
	
@Autowired // if annotated as repository then dont need to put entries in .xml
public void setSessionFactory(SessionFactory sf) {
    this.sessionFactory = sf;
}

	@Override
	public List<AuthorizedUser> fetchPassword(String email) {
		
		return null;
	}

	@Override
	public void AddUser(AuthorizedUser authuser) {
	
        Session session = this.sessionFactory.openSession();
        tcx = session.beginTransaction();
       session.save(authuser);
        tcx.commit();
        session.close();
		
	}

	@Override
	public boolean verifyUser(String username, String password) {
		Session session = this.sessionFactory.openSession();
       System.out.println(username);
      Query q=  session.createQuery("from AuthorizedUser where userEmail=:userEmail and password=:password");
        q.setString("userEmail", username);
        q.setString("password", password);
        List l=q.list();
   
   if(l.isEmpty())
	   {
	   return false;
	   }

	
	
session.close();
return true;
   
}
}
