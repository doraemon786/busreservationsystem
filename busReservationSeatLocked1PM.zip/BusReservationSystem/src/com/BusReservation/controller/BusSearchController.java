package com.BusReservation.controller;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.BusReservation.model.BusSearchDetails;
import com.BusReservation.service.IAuthorizedUserService;
import com.BusReservation.service.IBusSearchService;

@Controller
@SessionAttributes({"BusList"})
public class BusSearchController {
@Autowired
IAuthorizedUserService authorizedUserService;

@Autowired
IBusSearchService bussearchservice;

	@RequestMapping(value="/SearchBus",method=RequestMethod.POST)
	public String validateregistrationPage(Model model,HttpServletRequest req,HttpSession session)
	{
System.out.println("inside search bus "+session.getAttribute("username"));
		String sectorfrom=req.getParameter("source");
		String sectorto=req.getParameter("destination");
		String journeyDate=req.getParameter("journeyDate");
		String returnDate=req.getParameter("returnDate");
/*	System.out.println(sectorfrom);
	System.out.println(sectorto);
	System.out.println(journeyDate);
	System.out.println(returnDate);*/
	
	
	List busList=bussearchservice.fetchBus(sectorfrom,sectorto,journeyDate,returnDate);
	ServletContext servletContext=req.getServletContext();

	servletContext.setAttribute("BusList", busList); 	
	//session.setAttribute("BusList",busList);
			System.out.println(busList);
			String view="SearchResult";
			return view;
	}
	}

