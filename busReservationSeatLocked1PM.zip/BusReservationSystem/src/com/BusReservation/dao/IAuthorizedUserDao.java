package com.BusReservation.dao;

import java.util.ArrayList;
import java.util.List;

import com.BusReservation.model.AuthorizedUser;
import com.BusReservation.model.BusDetails;
import com.BusReservation.model.PassengerDetails;

public interface IAuthorizedUserDao {
	public List fetchPassword(String email);
	
	public void AddUser(AuthorizedUser authuser);
	
	boolean verifyUser(String username,String password);
	
	public List<AuthorizedUser> getUserDetails(String username);
	
	public List<BusDetails> getBusDetails(String busname);
	
	public List<PassengerDetails> registerPassenger(PassengerDetails pdetail) ;
	
	public boolean seatCalculate(String seattotal, int busId);


	public ArrayList<String> getBookedSeats(String busname);
}
