package com.BusReservation.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.BusReservation.model.AuthorizedUser;
import com.BusReservation.model.BusDetails;
import com.BusReservation.model.PassengerDetails;


@Repository
public class AuthorizedUserDaoImpl  implements IAuthorizedUserDao {
		
		static Transaction tx ;
		static Transaction tx1 ;
		private SessionFactory sessionFactory;
	
		@Autowired // if annotated as repository then dont need to put entries in .xml
		public void setSessionFactory(SessionFactory sf) {
			this.sessionFactory = sf;
		}

		@Override
		public List fetchPassword(String userEmail) {
		
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			Query query=  session.createQuery("from AuthorizedUser a where a.userEmail = :userEmail");
			query.setString("userEmail", userEmail);
			List<AuthorizedUser> list=query.list();
	if(list.isEmpty())
	{
		System.out.println("null");
		return null;
	}
			tx.commit();
			session.close();
			return list;
	       
	}

		@Override
		public void AddUser(AuthorizedUser authuser) {
	
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			session.save(authuser);
			tx.commit();
			session.close();

	}

		@Override
		public boolean verifyUser(String username, String password) {
		
			Session session = this.sessionFactory.openSession();
			String query="From AuthorizedUser a where a.userEmail = :username and a.password = :password";
			Query q=session.createQuery(query);
			q.setString("username", username);
			q.setString("password", password);
			List<AuthorizedUser> list = q.list();
		  
			if(list.size()==0)
			{
					return false;
			}
			session.close();
			return true;

}

		@Override
		public List<AuthorizedUser> getUserDetails(String username) {
			Session session = this.sessionFactory.openSession();
			
			if(username==null)
			{
				 username="guest@gmail.com";
			}
			String query="From AuthorizedUser a where a.userEmail = :username ";
			Query q=session.createQuery(query);
			q.setString("username", username);
			
		List<AuthorizedUser>	user =  q.list();
		System.out.println("inside dao..........."+user);
			return user;
		
		}

		@Override
		public List<BusDetails> getBusDetails(String busname) {
			Session session = this.sessionFactory.openSession();
			String query="From BusDetails b where b.busName = :busname ";
			Query q=session.createQuery(query);
			q.setString("busname", busname);
			
		List<BusDetails>	BusDetails =  q.list();
		System.out.println("inside dao...."+BusDetails);
			return BusDetails;
		
		}

		@Override
		public List<PassengerDetails> registerPassenger(PassengerDetails pdetail) {
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			
		
			session.save(pdetail);
			tx.commit();
			int pid=pdetail.getPassengerId();
			System.out.println("pid................."+pid);
			String query2="from PassengerDetails p where p.passengerId=:passengerId";
			Query q2=session.createQuery(query2);
			q2.setInteger("passengerId", pid);
			List<PassengerDetails> pdetails=q2.list();
		
			return pdetails;
			
		}

		@Override
		public boolean seatCalculate(String seattotal, int busId) {
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
	
			System.out.println("inside seatCalculate........");
			String query2="from BusDetails b where busId=:busId";
			Query q2=session.createQuery(query2);
			q2.setInteger("busId", busId);
			List<BusDetails> bDetails=q2.list();
			System.out.println("inside seatCalculateDao......"+bDetails);
			int seatTotal=Integer.valueOf(seattotal);
			System.out.println("inside seatCalculateDao seatTotal......"+seatTotal);
			int currentCapacity=bDetails.get(0).getSeatCapacity()-seatTotal;
			tx.commit();
			tx1 = session.beginTransaction();
			System.out.println("current Capacity...."+currentCapacity);
			if(currentCapacity>0)
			{
				System.out.println("inside condition.....");
			String query1="update BusDetails b set b.seatCapacity=:capacity where b.busId=:busId";
			Query q1=session.createQuery(query1);
			q1.setInteger("capacity", currentCapacity);
			q1.setInteger("busId", busId);
		int count=	q1.executeUpdate();
		
		
		String query3="from BusDetails b where busId=:busId";
		Query q3=session.createQuery(query3);
		q3.setInteger("busId", busId);
		
		List<BusDetails> busUpdated=q3.list();
		System.out.println(count);
			tx1.commit();
			
			System.out.println("inside condition....."+busUpdated);
			if(busUpdated.get(0).getSeatCapacity()>0)
			{
				System.out.println("inside inner condition.....");
	/*			tx1.commit();*/
				return true;
			}
			return false;
	
			
		}
			return false;
			
		}

		@Override
		public ArrayList<String> getBookedSeats(String busname) {
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			String query="select p.seat From PassengerDetails p where p.busName=:busName ";
			
			Query q1=session.createQuery(query);
			q1.setString("busName", busname);
			ArrayList<String> seat=(ArrayList<String>) q1.list();
			System.out.println("seat of passenger..................................."+seat);
			return seat;
		}
}

		

