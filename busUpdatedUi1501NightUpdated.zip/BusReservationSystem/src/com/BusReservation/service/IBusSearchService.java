package com.BusReservation.service;

import java.util.List;

import com.BusReservation.model.Sector;

public interface IBusSearchService {
	


	List fetchBus(String sectorfrom, String sectorto, String journeyDate, String returnDate);

}
