package com.BusReservation.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Stoppage implements Serializable{

	
	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int stopId;
	private String location;
	@ManyToOne  
	 @JoinColumn(name = "sectorId")  
	private Sector sector;

	public Stoppage( String location, Sector sector) {
		super();
		
		this.location = location;
		this.sector = sector;
	}

	public Stoppage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getStopId() {
		return stopId;
	}

	

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Sector getSector() {
		return sector;
	}

	public void setSector(Sector sector) {
		this.sector = sector;
	}

	@Override
	public String toString() {
		return "Stoppage [stopId=" + stopId + ", location=" + location + ", sector=" + sector + "]";
	}

	
}
