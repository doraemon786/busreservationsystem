package com.BusReservation.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class BusDetails implements Serializable {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
	private int busId;
	private String busName;
	private String busType;
	private String day;
	@OneToOne(cascade=CascadeType.ALL)
	private Sector sector;
	
	
	public BusDetails() {
		super();
	}


	public BusDetails( String busName, String busType, String day, Sector sector) {
		super();
		
		this.busName = busName;
		this.busType = busType;
		this.day = day;
		this.sector = sector;
	}


	public int getBusId() {
		return busId;
	}


	


	public String getBusName() {
		return busName;
	}


	public void setBusName(String busName) {
		this.busName = busName;
	}


	public String getBusType() {
		return busType;
	}


	public void setBusType(String busType) {
		this.busType = busType;
	}


	public String getDay() {
		return day;
	}


	public void setDay(String day) {
		this.day = day;
	}


	public Sector getSector() {
		return sector;
	}


	public void setSector(Sector sector) {
		this.sector = sector;
	}


	@Override
	public String toString() {
		return "BusDetails [busId=" + busId + ", busName=" + busName + ", busType=" + busType + ", day=" + day
				+ ", sector=" + sector + "]";
	}
	
}
