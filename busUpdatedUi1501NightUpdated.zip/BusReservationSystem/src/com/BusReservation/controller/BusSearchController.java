package com.BusReservation.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.BusReservation.model.AuthorizedUser;
import com.BusReservation.model.BusDetails;
import com.BusReservation.model.Sector;
import com.BusReservation.service.IAuthorizedUserService;
import com.BusReservation.service.IBusSearchService;

@Controller
public class BusSearchController {
@Autowired
IAuthorizedUserService authorizedUserService;

@Autowired
IBusSearchService bussearchservice;

	@RequestMapping(value="/SearchBus",method=RequestMethod.POST)
	public String validateregistrationPage(@Valid 
BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		
		String sectorfrom=req.getParameter("sectorfrom");
		String sectorto=req.getParameter("sectorto");
		String journeyDate=req.getParameter("journeydate");
		String ReturnDate=req.getParameter("journeydate");
	

	
		String view="";
		if(bindingResult.hasErrors())
		{
			view="redirect:/HomePage";
			return view;
		}
		else
		{
	List busList=bussearchservice.fetchBus(sectorfrom,sectorto,journeyDate,ReturnDate);
			model.addAttribute("BusList", busList);
			System.out.println(busList);
			view="searchResultPage";
			return view;
	}
	}
}
