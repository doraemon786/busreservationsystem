package com.BusReservation.dao;

import java.util.List;

import com.BusReservation.model.Sector;

public interface IBusSearchDao {

	public List fetchBus(String sectorfrom, String sectorto, String journeyDate, String returnDate);
}
