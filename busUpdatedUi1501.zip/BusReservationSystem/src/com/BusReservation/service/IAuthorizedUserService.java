package com.BusReservation.service;

import java.util.List;
import com.BusReservation.model.AuthorizedUser;

public interface IAuthorizedUserService {
	List fetchPassword(String email);
	
	void AddUser(AuthorizedUser authuser);
	
	boolean verifyUser(String username,String passwrod);
	
}
