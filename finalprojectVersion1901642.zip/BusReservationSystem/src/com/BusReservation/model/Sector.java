/*package com.BusReservation.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

@Entity
public class Sector implements Serializable {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int sectorId;
	private String sectorFrom;
	private String sectorTo;

	@OneToMany(cascade= CascadeType.ALL,mappedBy="sector")
	private Set<Stoppage> stop;
	
public Sector() {
	super();
}
	
	public Sector( String sectorFrom, String sectorTo,  Set<Stoppage> stop) {
		super();
		
		this.sectorFrom = sectorFrom;
		this.sectorTo = sectorTo;
		this.stop = stop;
	}

	public int getSectorId() {
		return sectorId;
	}



	public String getSectorFrom() {
		return sectorFrom;
	}

	public void setSectorFrom(String sectorFrom) {
		this.sectorFrom = sectorFrom;
	}

	public String getSectorTo() {
		return sectorTo;
	}

	public void setSectorTo(String sectorTo) {
		this.sectorTo = sectorTo;
	}

	public Set<Stoppage> getStop() {
		return stop;
	}

	public void setStop(Set<Stoppage> stop) {
		this.stop = stop;
	}

	@Override
	public String toString() {
		return "Sector [sectorId=" + sectorId + ", sectorFrom=" + sectorFrom + ", sectorTo=" + sectorTo +" ]";
	}
	
	
}
*/