package com.BusReservation.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.ColumnDefault;

@Entity
public class AuthorizedUser implements Serializable {		//POJO for registered/authorized users
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int userId;	
	private String firstname;
	private String lastname;
	private String phoneNumber;						
	private String userEmail;			
	private String Gender;	
	private String password;

	@ColumnDefault("2000.0")
	private float wallet=2000;														
	
	public AuthorizedUser() {
		super();
	}
	
	public AuthorizedUser( String firstname, String lastname, String phoneNumber, String userEmail,
			String gender, String password, float wallet) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.phoneNumber = phoneNumber;
		this.userEmail = userEmail;
		Gender = gender;
		this.password = password;
		this.wallet = wallet;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public float getWallet() {
		return wallet;
	}

	public void setWallet(float wallet) {
		this.wallet = wallet;
	}

	@Override
	public String toString() {
		return "AuthorizedUser [userId=" + userId + ", firstname=" + firstname + ", lastname=" + lastname
				+ ", phoneNumber=" + phoneNumber + ", userEmail=" + userEmail + ", Gender=" + Gender + ", password="
				+ password + ", wallet=" + wallet + "]";
	}
	
}
