package com.BusReservation.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class BusDetails implements Serializable {
	
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
	private int busId;
	private String busName;
	private String busType;
	private int day;
	private String arrivalTime;
	private String departureTime;
	private String sectorFrom;
	private String sectorTo;
	private int seatCapacity=30;
	
	
	public BusDetails() {
		super();
	}

	public BusDetails(int busId, String busName, String busType, int day, String arrivalTime, String departureTime,
			String sectorFrom, String sectorTo) {
		super();
		this.busId = busId;
		this.busName = busName;
		this.busType = busType;
		this.day = day;
		this.arrivalTime = arrivalTime;
		this.departureTime = departureTime;
		this.sectorFrom = sectorFrom;
		this.sectorTo = sectorTo;
	}

	public String getBusName() {
		return busName;
	}

	public void setBusName(String busName) {
		this.busName = busName;
	}

	public String getBusType() {
		return busType;
	}

	public void setBusType(String busType) {
		this.busType = busType;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public String getSectorFrom() {
		return sectorFrom;
	}

	public void setSectorFrom(String sectorFrom) {
		this.sectorFrom = sectorFrom;
	}

	public String getSectorTo() {
		return sectorTo;
	}

	public void setSectorTo(String sectorTo) {
		this.sectorTo = sectorTo;
	}

	public int getBusId() {
		return busId;
	}

	public void setBusId(int busId) {
		this.busId = busId;
	}

	public int getSeatCapacity() {
		return seatCapacity;
	}

	public void setSeatCapacity(int seatCapacity) {
		this.seatCapacity = seatCapacity;
	}

	@Override
	public String toString() {
		return "BusDetails [busId=" + busId + ", busName=" + busName + ", busType=" + busType + ", day=" + day
				+ ", arrivalTime=" + arrivalTime + ", departureTime=" + departureTime + ", sectorFrom=" + sectorFrom
				+ ", sectorTo=" + sectorTo + "]";
	}

}
