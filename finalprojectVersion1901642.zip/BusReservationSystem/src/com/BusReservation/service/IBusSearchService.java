package com.BusReservation.service;

import java.util.List;

import com.BusReservation.model.BusDetails;


public interface IBusSearchService {

	List<BusDetails> fetchBus(String sectorfrom, String sectorto, String journeyDate, String returnDate);

}
