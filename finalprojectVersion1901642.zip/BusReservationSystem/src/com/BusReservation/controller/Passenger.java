package com.BusReservation.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.filter.HiddenHttpMethodFilter;

import com.BusReservation.model.AuthorizedUser;
import com.BusReservation.model.BusDetails;
import com.BusReservation.model.PassengerDetails;
import com.BusReservation.model.SelectedSeats;
import com.BusReservation.service.AuthorizedUserServiceImpl;

@Controller
public class Passenger {
	String passengerEmail;
@Autowired
AuthorizedUserServiceImpl authser;
	@RequestMapping(value="/seatBooking",method=RequestMethod.POST)
	public String showSeatSelection(Model modal,HttpServletRequest request,HttpSession ses)
	{
	System.out.println("inside seatbooking");
	System.out.println("inside seatbooking   "+ses.getAttribute("username"));
	
		String busname=request.getParameter("busname");
		
	List<String>	seatList=authser.getBookedSeats(busname);
	ses.setAttribute("BookedSeat", seatList.toString());
	ses.setAttribute("totalSeat", seatList.size());
	ses.setAttribute("busname", busname);
		System.out.println(busname);
	modal.addAttribute("seatdetails",new SelectedSeats());
		String view="SeatSelection";
		return view;
		
		
	}
	
	

	
	@RequestMapping(value="/seatBookingCall",method=RequestMethod.POST)
	public String validateregistrationPage(@Valid @ModelAttribute("seatdetails") 
	SelectedSeats selectedseats ,BindingResult bindingResult,Model model,HttpServletRequest req,HttpSession ses)
	{
		
		String view="";
		if(bindingResult.hasErrors())
		{
			view="SeatSelection";
			return view;
		}
		else
		{
			System.out.println("seatBookingCall "+ses.getAttribute("username"));
			System.out.println(ses.getAttribute("username"));
			System.out.println("hello world");
			System.out.println(req.getParameter("NumberDisplay"));
			ses.setAttribute("seatnumber", req.getParameter("NumberDisplay"));
			ses.setAttribute("seatvalue",req.getParameter("seatsDisplay"));
			System.out.println(req.getParameter("seatsDisplay"));
		
			return "FillPassengerDetails";
			
	}
	}
/*	private int passengerId;
	private String passengerName;
	private int age;
	private String passengerEmail;
	private String phoneNumber;
	private String busName;
	private String source;
	private String destination;
	private String seat;
	private int id;*/
	
	@RequestMapping("/RegisterPassenger")
	public String validateregistrationPage(HttpServletRequest req,HttpSession ses,Model model)
	{
		int userid;
		System.out.println("inside register passenger........");
		

		String seattotal=(String)ses.getAttribute("seatnumber");
		String busname=(String)ses.getAttribute("busname");
		passengerEmail=(String)ses.getAttribute("username");
		String seatno=(String)ses.getAttribute("seatvalue");
		
		
		
		System.out.println("inside register passenger.. controller"+passengerEmail);
		System.out.println("inside register passenger.."+busname);
		System.out.println("inside register passenger.."+seattotal);
		System.out.println("inside register passenger.."+seatno);
		
		
		
		if(passengerEmail!=null)
		{
			List<AuthorizedUser> user=authser.getUserDetails(passengerEmail);
		 userid=user.get(0).getUserId();
		}
		else
		{
			 userid=0;
		}
		
		List<BusDetails>  busDetails=authser.getBusDetails(busname);
		

		
		System.out.println("user id.."+userid);
		int busId=busDetails.get(0).getBusId();
		System.out.println("busid.."+busId);
		String source=busDetails.get(0).getSectorFrom();
		System.out.println("source"+source);
		String destination=busDetails.get(0).getSectorTo();
		System.out.println("destination"+destination);
		
		
		String passengerName=req.getParameter("passengername");
		System.out.println("passenger "+passengerName);
		int age=Integer.valueOf(req.getParameter("age"));
		System.out.println("age "+age);
		
		if(passengerEmail==null)
		{
		 passengerEmail=req.getParameter("email");
		System.out.println("email.. "+passengerEmail);
		}
	
	
		String phoneNumber=req.getParameter("phonenumber");
		System.out.println("phonenumber.. "+phoneNumber);
		
		String journeyDate=(String)ses.getAttribute("journeydate");

		System.out.println("inside.......printing journey date..."+journeyDate);
		PassengerDetails pdetail= new PassengerDetails(passengerName, age, passengerEmail, phoneNumber, busname, source, destination, seatno,journeyDate ,userid);
		System.out.println(pdetail);
/*	ses.setAttribute("pdetails", (List<PassengerDetails>)pdetail);*/

		
		if(authser.seatCalculate(seattotal,busId))
		{
			System.out.println("inside...controller");
		List<PassengerDetails> pdetails	=authser.registerPassenger(pdetail);
		
		List<BusDetails> bdetails=authser.getBusDetails(busname);
		System.out.println("inside.....looop"+pdetails);
		ses.setAttribute("pdetails", pdetails);
		ses.setAttribute("bdetails", bdetails);
			return "TransactionPage";
		}
		
		
		
			return "SeatSelection";
	}
	
	@RequestMapping("/TransactionCommit")
	public String showLoginView(Model modal)
	{
		
		String view="TransactionPage";
		return view;
	}
	
	
	
	}


