package com.BusReservation.dao;

import java.util.List;

import com.BusReservation.model.AuthorizedUser;

public interface IAuthorizedUserDao {
	public List fetchPassword(String email);
	
	public void AddUser(AuthorizedUser authuser);
	
	boolean verifyUser(String username,String password);
}
