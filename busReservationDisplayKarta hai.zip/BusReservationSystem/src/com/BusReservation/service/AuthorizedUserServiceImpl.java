package com.BusReservation.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BusReservation.dao.IAuthorizedUserDao;
import com.BusReservation.model.AuthorizedUser;

@Service
@Transactional
public class AuthorizedUserServiceImpl implements IAuthorizedUserService {

	@Autowired
	IAuthorizedUserDao authorizedUserDao;
	
	@Override
	public List fetchPassword(String email) {
		
		return authorizedUserDao.fetchPassword(email);
	}

	@Override
	public void AddUser(AuthorizedUser authuser) {
		authorizedUserDao.AddUser(authuser);
		
	}

	@Override
	public boolean verifyUser(String username, String password) {
		return authorizedUserDao.verifyUser(username, password);
	}

	
}
