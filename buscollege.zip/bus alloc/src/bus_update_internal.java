

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.jmx.snmp.Timestamp;


/**
 * Servlet implementation class bus_update_internal
 */
@WebServlet("/bus_update_internal")
public class bus_update_internal extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public bus_update_internal() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String bus_no = request.getParameter("bus_no")+"";    
		    String driver_name = request.getParameter("driver_name")+"";
		    String driver_id = request.getParameter("driver_id")+"";
		    String driver_mob = request.getParameter("mob_no")+"";
		    String destination = request.getParameter("dest")+"";
		    String seat_avail = request.getParameter("seat_avail")+"";
		    System.out.println(driver_name+" "+bus_no+" "+driver_id+" "+driver_mob+" "+destination+" "+seat_avail);
		    String bus_timing = request.getParameter("bus_timing")+":00";
		    DateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		    Date d=null;
		    java.util.Date dd=null;
		    java.sql.Timestamp t1=null;
		    try {
		    	d=new Date(df.parse(bus_timing).getTime());
				dd=new java.util.Date(d.getTime());
		    		
				t1=new java.sql.Timestamp(dd.getTime());
			} catch (ParseException e1) {
				e1.printStackTrace();
			}
		    System.out.println(d.getTime());
		    
		    PrintWriter out = response.getWriter(); 
		  //  String query= "insert into student_bus(Bus_no, Driver_name, driver_id, driver mobile no, destination, Bus seat available, bus_timing) VALUES ('" + bus_no + "','"+driver_name+"','"+driver_id+"','"+driver_mob+"','"+destination+"','"+seat_avail+"','"+bus_timing+"')";
		try {
			   Class.forName("com.mysql.jdbc.Driver");
			  } 
			        catch (ClassNotFoundException e) {
			   System.out.println(e.getMessage());
			  }
		try{

		  Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project",
		        "root", "");
		   
		  PreparedStatement ps=con.prepareStatement(  
	    		  "insert into student_bus values(?,?,?,?,?,?,?,?)"); 
		  ps.setInt(1,Integer.parseInt(bus_no));  
		  ps.setString(2,driver_name);  
		  ps.setInt(3,Integer.parseInt(driver_id)); 
		  try{
		  ps.setLong(4,Long.parseLong(driver_mob));  
		  }
		  catch(Exception e)
		  {
			  System.out.println("success");
		  }
		  ps.setString(5,destination);  
		  ps.setInt(6,Integer.parseInt(seat_avail));  
		  ps.setDate(7, d);
		  ps.setTimestamp(8, t1);
		 // ps.setString(7,bus_timing);  
		    Statement st = con.createStatement();
		    //ResultSet rs;
		   
		    int i=ps.executeUpdate();
		   if(i>0)
		    {
			   System.out.println("Data is successfully inserted!");
		    }
		}
		    catch (SQLException e) {
		        
		    } 
		out.close(); 
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
