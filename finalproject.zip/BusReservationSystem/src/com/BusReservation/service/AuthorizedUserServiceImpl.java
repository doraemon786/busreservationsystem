package com.BusReservation.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BusReservation.dao.IAuthorizedUserDao;
import com.BusReservation.model.AuthorizedUser;
import com.BusReservation.model.BusDetails;
import com.BusReservation.model.PassengerDetails;

@Service
@Transactional
public class AuthorizedUserServiceImpl implements IAuthorizedUserService {

	@Autowired
	IAuthorizedUserDao authorizedUserDao;
	
	@Override
	public List fetchPassword(String email) {
		
		return authorizedUserDao.fetchPassword(email);
	}

	@Override
	public void AddUser(AuthorizedUser authuser) {
		authorizedUserDao.AddUser(authuser);
		
	}

	@Override
	public boolean verifyUser(String username, String password) {
		return authorizedUserDao.verifyUser(username, password);
	}

	public List<AuthorizedUser> getUserDetails(String username) {
		
		return authorizedUserDao.getUserDetails(username);
	
		
	}

	public List<BusDetails> getBusDetails(String busname) {
		
		return authorizedUserDao.getBusDetails(busname);
	}

	public List<PassengerDetails> registerPassenger(PassengerDetails pdetail) {
		return authorizedUserDao.registerPassenger(pdetail);
		
	}

	public boolean seatCalculate(String seattotal, int busId) {
		
		return authorizedUserDao.seatCalculate(seattotal, busId);
		
	}

	public ArrayList<String> getBookedSeats(String busname) {
		
		return authorizedUserDao.getBookedSeats(busname);
	}

	@Override
	public List<PassengerDetails> fetchPassengerDetails(String username) {
	
		return authorizedUserDao.fetchPassengerDetails(username);
	}

	
}
