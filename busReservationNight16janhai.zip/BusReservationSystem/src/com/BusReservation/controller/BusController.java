package com.BusReservation.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.BusReservation.model.AuthorizedUser;
import com.BusReservation.service.IAuthorizedUserService;

@Controller
public class BusController {

@Autowired
IAuthorizedUserService authorizedUserService;

@RequestMapping(value= {"/"})
public ModelAndView goHome()
{
	ModelAndView mv= new ModelAndView();
	mv.setViewName("index.jsp");
	return mv;
}


	@RequestMapping("/HomePage")
	public String showLoginView(Model modal)
	{
		modal.addAttribute("authuser", new AuthorizedUser());
		String view="LoginView";
		return view;
	}
	
	@RequestMapping(value="/LoginVerification",method=RequestMethod.POST)
	public String LoginValidation(Model model,HttpServletRequest req)
	{
		String username=req.getParameter("username");
		String password=req.getParameter("password");
		
	//	System.out.println("this is password"+password);
		if(authorizedUserService.verifyUser(username, password))
		{
		return "Dashboard";
		}
		return "LoginView";
		
	}
	
	@RequestMapping(value="/registerPage",method=RequestMethod.POST)
	public String validateregistrationPage(@Valid @ModelAttribute("authuser") 
	AuthorizedUser authuser ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		
		String view="";
		if(bindingResult.hasErrors())
		{
			view="LoginView";
			return view;
		}
		else
		{
			authorizedUserService.AddUser(authuser);
			
			
			return "redirect:/";
	}
	}
	
	@RequestMapping("/Forgot")
	public String showForgetPassword(Model model,HttpServletRequest request)
	{
		String view="ForgetPassword";
		return view;
	}
	
	@RequestMapping(value="/ForgotProcessing",method=RequestMethod.POST)
	public void  ProcessPassword(HttpServletRequest req)
	{
		String userEmail=req.getParameter("email");
		List<AuthorizedUser> UserDetails=authorizedUserService.fetchPassword(userEmail);		
		System.out.println(UserDetails);
}
	
	@RequestMapping(value="/PassengerDetails",method=RequestMethod.POST)
	public String showPassengerForm(Model modal,HttpServletRequest request)
	{
		String busname=request.getParameter("busname");
		System.out.println(busname);
		String view="FillPassengerDetails";
		return view;
	}
}
