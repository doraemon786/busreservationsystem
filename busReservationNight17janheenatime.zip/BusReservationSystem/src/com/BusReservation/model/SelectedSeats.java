package com.BusReservation.model;

import java.util.Arrays;

public class SelectedSeats {

	private int noofSeats;
	private String Seat[];
	
	public SelectedSeats() {
		
	}
	
	
	public SelectedSeats(int noofSeats, String[] seat) {
		super();
		this.noofSeats = noofSeats;
		Seat = seat;
	}


	public int getNoofSeats() {
		return noofSeats;
	}
	public void setNoofSeats(int noofSeats) {
		this.noofSeats = noofSeats;
	}
	public String[] getSeat() {
		return Seat;
	}
	public void setSeat(String[] seat) {
		Seat = seat;
	}
	@Override
	public String toString() {
		return "SelectedSeats [noofSeats=" + noofSeats + ", Seat=" + Arrays.toString(Seat) + "]";
	}
	
	
}
