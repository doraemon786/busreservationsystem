package com.BusReservation.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class PassengerDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int passengerId;
	private String passengerName;
	private int age;
	private String passengerEmail;
	private String phoneNumber;
	private String busName;
	private String source;
	private String destination;
	private String seat;
	private int id;
	public int getPassengerId() {
		return passengerId;
	}
	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPassengerEmail() {
		return passengerEmail;
	}
	public void setPassengerEmail(String passengerEmail) {
		this.passengerEmail = passengerEmail;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getBusName() {
		return busName;
	}
	public void setBusName(String busName) {
		this.busName = busName;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
	public String getSeat() {
		return seat;
	}
	public void setSeat(String seat) {
		this.seat = seat;
	}
	public PassengerDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PassengerDetails(int passengerId, String passengerName, int age, String passengerEmail, String phoneNumber,
			String busName, String source, String destination, String seat, int id) {
		super();
		this.passengerId = passengerId;
		this.passengerName = passengerName;
		this.age = age;
		this.passengerEmail = passengerEmail;
		this.phoneNumber = phoneNumber;
		this.busName = busName;
		this.source = source;
		this.destination = destination;
		this.seat = seat;
		this.id = id;
	}
	
	
	
}
