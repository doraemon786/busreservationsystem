package com.BusReservation.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.BusReservation.model.AuthorizedUser;

@Repository
public class AuthorizedUserDaoImpl  implements IAuthorizedUserDao {
		
		static Transaction tx ;
		private SessionFactory sessionFactory;
	
		@Autowired // if annotated as repository then dont need to put entries in .xml
		public void setSessionFactory(SessionFactory sf) {
			this.sessionFactory = sf;
		}

		@Override
		public List fetchPassword(String userEmail) {
		
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			Query query=  session.createQuery("from AuthorizedUser a where a.userEmail = :userEmail");
			query.setString("userEmail", userEmail);
			List<AuthorizedUser> list=query.list();
	if(list.isEmpty())
	{
		System.out.println("null");
		return null;
	}
			tx.commit();
			session.close();
			return list;
	       
	}

		@Override
		public void AddUser(AuthorizedUser authuser) {
	
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			session.save(authuser);
			tx.commit();
			session.close();

	}

		@Override
		public boolean verifyUser(String username, String password) {
		
			Session session = this.sessionFactory.openSession();
			String query="From AuthorizedUser a where a.userEmail = :username and a.password = :password";
			Query q=session.createQuery(query);
			q.setString("username", username);
			q.setString("password", password);
			List<AuthorizedUser> list = q.list();
		  
			if(list.size()==0)
			{
					return false;
			}
			session.close();
			return true;

}
}
