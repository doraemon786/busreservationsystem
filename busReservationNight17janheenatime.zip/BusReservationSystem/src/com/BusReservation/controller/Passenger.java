package com.BusReservation.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.jpa.criteria.expression.SearchedCaseExpression;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.BusReservation.model.AuthorizedUser;
import com.BusReservation.model.SelectedSeats;
@Controller
public class Passenger {
	HttpSession session;

	@RequestMapping(value="/seatBooking",method=RequestMethod.POST)
	public String showSeatSelection(Model modal,HttpServletRequest request)
	{
	System.out.println("inside seatbooking");
		String busname=request.getParameter("busname");
	/*	session.setAttribute("Busname", busname);*/
		System.out.println(busname);
		modal.addAttribute("seatdetails",new SelectedSeats());
		String view="SeatSelection";
		return view;
	}
	
	

	
	@RequestMapping(value="/seatBookingCall",method=RequestMethod.POST)
	public String validateregistrationPage(@Valid @ModelAttribute("seatdetails") 
	SelectedSeats selectedseats ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		
		String view="";
		if(bindingResult.hasErrors())
		{
			view="SeatSelection";
			return view;
		}
		else
		{
			System.out.println("hello world");
			System.out.println(selectedseats.getNoofSeats());
			System.out.println(selectedseats.getSeat());
			model.addAttribute("totalseats", selectedseats.getNoofSeats());
			System.out.println(req.getParameter("NumberDisplay"));
			
			return "FillPassengerDetails";
	}
	}
}
